const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

if (menuToggle && navLinks) {
  menuToggle.addEventListener("click", () => {
    navLinks.classList.toggle("active");
  });

  navLinks.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("active");
    });
  });
}

const reveals = document.querySelectorAll(".reveal");

function revealOnScroll() {
  const windowHeight = window.innerHeight;

  reveals.forEach((el) => {
    const top = el.getBoundingClientRect().top;
    if (top < windowHeight - 80) {
      el.classList.add("active");
    }
  });
}

window.addEventListener("scroll", revealOnScroll);
window.addEventListener("load", revealOnScroll);

const cards = document.querySelectorAll(".card");

cards.forEach((card) => {
  card.addEventListener("mousemove", (e) => {
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const rotateX = -((y / rect.height) - 0.5) * 8;
    const rotateY = ((x / rect.width) - 0.5) * 8;

    card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-6px)`;
  });

  card.addEventListener("mouseleave", () => {
    card.style.transform = "perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)";
  });
});

function createShootingStar() {
  const star = document.createElement("div");
  star.className = "shooting-star";

  star.style.top = `${Math.random() * window.innerHeight * 0.5}px`;
  star.style.left = `${Math.random() * window.innerWidth * 0.6}px`;

  document.body.appendChild(star);

  setTimeout(() => {
    star.remove();
  }, 2000);
}

setInterval(createShootingStar, 2400);

// const contactForm = document.querySelector(".contact-form");

// if (contactForm) {
//   contactForm.addEventListener("submit", (e) => {
//     e.preventDefault();
//     alert("Thanks! Your message has been captured in this demo form.");
//     contactForm.reset();
//   });
// }

document.addEventListener("mousemove", (e) => {
  const heroLights = document.querySelectorAll(".hero-light");

  heroLights.forEach((light, index) => {
    const speed = index === 0 ? 0.012 : 0.02;
    const x = (e.clientX - window.innerWidth / 2) * speed;
    const y = (e.clientY - window.innerHeight / 2) * speed;
    light.style.transform = `translate(${x}px, ${y}px)`;
  });
});

/* Interactive Pathfinder */
const pathButtons = document.querySelectorAll(".path-btn");
const pathTitle = document.getElementById("path-title");
const pathDesc = document.getElementById("path-desc");
const tag1 = document.getElementById("tag1");
const tag2 = document.getElementById("tag2");
const tag3 = document.getElementById("tag3");

pathButtons.forEach((button) => {
  button.addEventListener("click", () => {
    pathButtons.forEach((btn) => btn.classList.remove("active"));
    button.classList.add("active");

    pathTitle.textContent = button.dataset.title;
    pathDesc.textContent = button.dataset.desc;
    tag1.textContent = button.dataset.tag1;
    tag2.textContent = button.dataset.tag2;
    tag3.textContent = button.dataset.tag3;
  });
});

/* =========================
   INSANE CASE STUDY SCROLL
========================= */

const storySteps = document.querySelectorAll(".story-step");
const visualScreens = document.querySelectorAll(".visual-screen");
const progressDots = document.querySelectorAll(".progress-dot");

function updateCaseStudyState() {
  if (!storySteps.length) return;

  let activeIndex = 0;
  const triggerPoint = window.innerHeight * 0.42;

  storySteps.forEach((step, index) => {
    const rect = step.getBoundingClientRect();
    if (rect.top <= triggerPoint) {
      activeIndex = index;
    }
  });

  storySteps.forEach((step, index) => {
    step.classList.toggle("active", index === activeIndex);
  });

  visualScreens.forEach((screen, index) => {
    screen.classList.toggle("active", index === activeIndex);
  });

  progressDots.forEach((dot, index) => {
    dot.classList.toggle("active", index === activeIndex);
  });
}

window.addEventListener("scroll", updateCaseStudyState);
window.addEventListener("load", updateCaseStudyState);

/* tiny parallax inside case visual */
document.addEventListener("mousemove", (e) => {
  const activeVisual = document.querySelector(".visual-screen.active");
  if (!activeVisual) return;

  const shell = document.querySelector(".case-visual-shell");
  if (!shell) return;

  const rect = shell.getBoundingClientRect();
  const x = ((e.clientX - rect.left) / rect.width - 0.5) * 10;
  const y = ((e.clientY - rect.top) / rect.height - 0.5) * 10;

  const glow = shell.querySelector(".visual-glow");
  if (glow) {
    glow.style.transform = `translate(calc(-50% + ${x * 1.8}px), ${y * 1.2}px)`;
  }
});
/* Theme toggle */
const root = document.documentElement;
const themeToggle = document.querySelector('.theme-toggle');
const themeLabel = document.querySelector('.theme-toggle-label');
const savedTheme = localStorage.getItem('site-theme');
const forcedTheme = new URLSearchParams(window.location.search).get('theme');

function updateThemeAwareLogos(theme) {
  document.querySelectorAll('.theme-aware-logo').forEach((img) => {
    const nextSrc = theme === 'light' ? img.dataset.logoLight : img.dataset.logoDark;
    if (nextSrc) {
      img.setAttribute('src', nextSrc);
    }
  });
}

function applyTheme(theme) {
  if (theme === 'light') {
    root.setAttribute('data-theme', 'light');
    if (themeLabel) themeLabel.textContent = 'Light';
  } else {
    root.removeAttribute('data-theme');
    if (themeLabel) themeLabel.textContent = 'Dark';
  }

  updateThemeAwareLogos(theme);
}

if (forcedTheme === 'light' || forcedTheme === 'dark') {
  applyTheme(forcedTheme);
} else {
  applyTheme(savedTheme === 'light' ? 'light' : 'dark');
}

if (themeToggle) {
  themeToggle.addEventListener('click', () => {
    const nextTheme = root.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
    applyTheme(nextTheme);
    localStorage.setItem('site-theme', nextTheme);
  });
}

/* PNG fallbacks */
function setupImageFallbacks() {
  document.querySelectorAll('.png-slot, .gallery-media').forEach((slot) => {
    const img = slot.querySelector('img');
    if (!img) {
      slot.classList.add('empty');
      return;
    }

    const markEmpty = () => {
      slot.classList.add('empty');
      img.classList.add('is-missing');
    };

    if (!img.getAttribute('src')) {
      markEmpty();
      return;
    }

    img.addEventListener('error', markEmpty, { once: true });

    if (img.complete && img.naturalWidth === 0) {
      markEmpty();
    }
  });
}

window.addEventListener('load', setupImageFallbacks);
