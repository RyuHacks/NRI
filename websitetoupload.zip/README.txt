FILES INCLUDED
- site.html
- case-study-detail.html
- thanks.html
- styles.css
- script.js
- assets/case-study/ (put your PNGs here)

PNG SLOTS ON MAIN PAGE
- assets/case-study/onboarding.png
- assets/case-study/workflows.png
- assets/case-study/support.png
- assets/case-study/platform.png

PNG SLOTS ON DETAIL PAGE
- assets/case-study/detail-hero.png
- assets/case-study/detail-architecture.png
- assets/case-study/detail-docs.png
- assets/case-study/detail-outcome.png

HOW TO USE
1. Keep all files in the same folder structure.
2. Open site.html in your browser.
3. Replace the placeholder image paths with your own images, or keep the same names and just drop your PNGs into assets/case-study/.
4. The theme toggle saves the user's choice in local storage.

LIGHT/DARK MODE TWEAKS INCLUDED
- The header logo now switches automatically with the site theme.
- Dark theme uses: logo-light.png
- Light theme uses: logo-dark.png
- The desktop nav bar no longer shows the light-mode white strip behind the links.
- The light-mode header was softened so it blends into the hero/banner better.
