// ─────────────────────────────────────────────────────────────────────────────
// NDGO · HEADFOOT.JS
// Minimal business tech · dark/light toggle · services mega dropdown
// Drop-in: add <div id="header-placeholder"> and <div id="footer-placeholder">
// ─────────────────────────────────────────────────────────────────────────────

const headerHTML = `
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
  :root {
    --ndgo-h:       64px;
    --ndgo-white:   #ffffff;
    --ndgo-bg:      #fafafa;
    --ndgo-ink:     #111111;
    --ndgo-mid:     #6b7280;
    --ndgo-rule:    #e5e7eb;
    --ndgo-accent:  #2563eb;
    --ndgo-accent-bg: #eff6ff;
    --ndgo-ff:      'Inter', -apple-system, sans-serif;
    --ndgo-trans:   0.18s ease;
  }

  [data-theme="dark"] {
    --ndgo-white:   #0f1117;
    --ndgo-bg:      #1a1c25;
    --ndgo-ink:     #f0f0f3;
    --ndgo-mid:     #9ca3af;
    --ndgo-rule:    #2a2d38;
    --ndgo-accent:  #60a5fa;
    --ndgo-accent-bg: #1e293b;
  }

  /* ── Reset scoping ── */
  .ndgo-header, .ndgo-header *,
  .ndgo-mobile-nav, .ndgo-mobile-nav *,
  .ndgo-footer, .ndgo-footer * {
    font-family: var(--ndgo-ff);
    box-sizing: border-box;
    margin: 0; padding: 0;
  }

  /* ═══════════════════════════════════════════════════════════════
     HEADER
     ═══════════════════════════════════════════════════════════════ */
  .ndgo-header {
    position: fixed;
    top: 0; left: 0; right: 0;
    height: var(--ndgo-h);
    z-index: 9999;
    background: rgba(255,255,255,0);
    border-bottom: 1px solid transparent;
    transition: background var(--ndgo-trans), border-color var(--ndgo-trans);
  }

  [data-theme="dark"] .ndgo-header {
    background: rgba(15,17,23,0);
  }

  .ndgo-header.is-scrolled,
  .ndgo-header.menu-open {
    background: rgba(255,255,255,0.92);
    border-bottom-color: var(--ndgo-rule);
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
  }

  [data-theme="dark"] .ndgo-header.is-scrolled,
  [data-theme="dark"] .ndgo-header.menu-open {
    background: rgba(15,17,23,0.92);
  }

  .ndgo-header-inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 40px;
    height: 100%;
    display: flex;
    align-items: center;
    gap: 48px;
    position: relative; /* anchor for full-width dropdown */
  }

  /* ── Logo ── */
  .ndgo-logo {
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 9px;
    flex-shrink: 0;
  }

  .ndgo-logo-mark {
    font-size: 15px;
    font-weight: 700;
    letter-spacing: 3.5px;
    color: var(--ndgo-ink);
    text-transform: uppercase;
    position: relative;
    padding-bottom: 2px;
  }

  .ndgo-logo-mark::after {
    content: '';
    position: absolute;
    bottom: 0; left: 0;
    width: 100%; height: 2px;
    background: var(--ndgo-accent);
    border-radius: 1px;
  }

  .ndgo-logo-dot {
    width: 5px; height: 5px;
    border-radius: 50%;
    background: var(--ndgo-accent);
    flex-shrink: 0;
    margin-bottom: 1px;
  }

  /* ── Nav links ── */
  .ndgo-nav {
    display: flex;
    align-items: center;
    gap: 2px;
    flex: 1;
  }

  .ndgo-nav-item { position: static; } /* static so dropdown positions to header-inner */

  .ndgo-nav-link {
    text-decoration: none;
    font-size: 13.5px;
    font-weight: 400;
    color: var(--ndgo-mid);
    padding: 6px 12px;
    border-radius: 6px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    transition: color var(--ndgo-trans), background var(--ndgo-trans);
    white-space: nowrap;
  }

  .ndgo-nav-link:hover { color: var(--ndgo-ink); background: var(--ndgo-bg); }

  .ndgo-nav-chevron {
    width: 8px; height: 8px;
    opacity: 0.4;
    transition: transform var(--ndgo-trans);
    flex-shrink: 0;
  }

  .ndgo-nav-item:hover .ndgo-nav-chevron {
    transform: rotate(180deg); opacity: 0.7;
  }

  /* ── Services mega dropdown — full width of header-inner ── */
  .ndgo-dropdown {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: var(--ndgo-white);
    border: 1px solid var(--ndgo-rule);
    border-top: none;
    border-radius: 0 0 14px 14px;
    box-shadow: 0 16px 48px rgba(0,0,0,0.10), 0 4px 12px rgba(0,0,0,0.04);
    padding: 0;
    opacity: 0;
    visibility: hidden;
    transform: translateY(-4px);
    pointer-events: none;
    transition: opacity 0.22s ease, transform 0.22s ease, visibility 0.22s ease;
    z-index: 100;
  }

  /* Hover bridge — invisible layer that covers the gap between the
     Services link and the dropdown panel so the cursor doesn't "fall off" */
  .ndgo-dropdown::before {
    content: '';
    position: absolute;
    bottom: 100%;
    left: 0; right: 0;
    height: 20px; /* generous bridge */
  }

  .ndgo-nav-item:hover .ndgo-dropdown {
    opacity: 1; visibility: visible;
    transform: translateY(0);
    pointer-events: auto;
  }

  .ndgo-dd-inner {
    display: grid;
    grid-template-columns: 280px 1fr;
    min-height: 0;
  }

  .ndgo-dd-intro {
    padding: 28px 28px 28px 28px;
    border-right: 1px solid var(--ndgo-rule);
    display: flex;
    flex-direction: column;
    justify-content: center;
  }

  .ndgo-dd-intro h4 {
    font-size: 14px;
    font-weight: 600;
    color: var(--ndgo-ink);
    margin: 0 0 8px;
    letter-spacing: -0.2px;
  }

  .ndgo-dd-intro p {
    font-size: 13px;
    font-weight: 300;
    color: var(--ndgo-mid);
    margin: 0;
    line-height: 1.6;
  }

  .ndgo-dd-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2px;
    padding: 10px;
  }

  .ndgo-dd-item {
    display: block;
    text-decoration: none;
    padding: 14px 16px;
    border-radius: 10px;
    transition: background var(--ndgo-trans);
  }

  .ndgo-dd-item:hover { background: var(--ndgo-bg); }

  .ndgo-dd-item strong {
    display: block;
    font-size: 13px;
    font-weight: 500;
    color: var(--ndgo-ink);
    margin-bottom: 3px;
  }

  .ndgo-dd-item span {
    display: block;
    font-size: 12px;
    font-weight: 300;
    color: var(--ndgo-mid);
    line-height: 1.45;
  }

  /* ── Right side ── */
  .ndgo-header-right {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-shrink: 0;
  }

  .ndgo-cta {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: var(--ndgo-ink);
    color: var(--ndgo-white);
    text-decoration: none;
    font-size: 13.5px;
    font-weight: 500;
    padding: 8px 18px;
    border-radius: 7px;
    transition: background var(--ndgo-trans), transform var(--ndgo-trans);
    white-space: nowrap;
    flex-shrink: 0;
    letter-spacing: -0.1px;
  }

  .ndgo-cta:hover { opacity: 0.85; transform: translateY(-1px); }

  /* ── Theme toggle ── */
  .ndgo-theme-toggle {
    background: var(--ndgo-bg);
    border: 1px solid var(--ndgo-rule);
    border-radius: 7px;
    width: 38px; height: 38px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    flex-shrink: 0;
    transition: background var(--ndgo-trans), border-color var(--ndgo-trans);
    font-size: 16px;
    line-height: 1;
    color: var(--ndgo-mid);
  }

  .ndgo-theme-toggle:hover {
    background: var(--ndgo-rule);
    border-color: #d1d5db;
  }

  [data-theme="dark"] .ndgo-theme-toggle:hover {
    background: #2a2d38;
    border-color: #3a3d48;
  }

  /* ── Hamburger ── */
  .ndgo-ham {
    display: none;
    background: var(--ndgo-white);
    border: 1px solid var(--ndgo-rule);
    border-radius: 8px;
    width: 38px; height: 38px;
    align-items: center; justify-content: center;
    cursor: pointer;
    flex-shrink: 0;
    transition: background var(--ndgo-trans), border-color var(--ndgo-trans);
  }

  .ndgo-ham:hover { background: var(--ndgo-bg); border-color: #d1d5db; }
  .ndgo-ham svg { width: 16px; height: 16px; color: var(--ndgo-ink); }

  .ndgo-ham-line {
    transition: transform 0.25s ease, opacity 0.25s ease;
    transform-origin: 50% 50%;
    transform-box: fill-box;
  }
  .ndgo-ham.open .ndgo-ham-top    { transform: translateY(3.5px) rotate(45deg); }
  .ndgo-ham.open .ndgo-ham-mid    { opacity: 0; }
  .ndgo-ham.open .ndgo-ham-bottom { transform: translateY(-3.5px) rotate(-45deg); }

  /* ═══════════════════════════════════════════════════════════════
     MOBILE NAV
     ═══════════════════════════════════════════════════════════════ */
  .ndgo-mobile-nav {
    position: fixed;
    top: calc(var(--ndgo-h) + 8px);
    left: 12px; right: 12px;
    background: var(--ndgo-white);
    border: 1px solid var(--ndgo-rule);
    border-radius: 12px;
    box-shadow: 0 16px 48px rgba(0,0,0,0.09);
    padding: 12px;
    z-index: 9998;
    max-height: calc(100vh - var(--ndgo-h) - 24px);
    overflow-y: auto;
    visibility: hidden;
    opacity: 0;
    transform: translateY(-6px) scale(0.99);
    pointer-events: none;
    transition: opacity var(--ndgo-trans), transform var(--ndgo-trans), visibility var(--ndgo-trans);
  }

  @media (min-width: 1025px) { .ndgo-mobile-nav { display: none !important; } }

  .ndgo-mobile-nav.open {
    visibility: visible;
    opacity: 1;
    transform: translateY(0) scale(1);
    pointer-events: auto;
  }

  .ndgo-mobile-nav > a,
  .ndgo-mobile-nav > div > .ndgo-mobile-drop-btn {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    padding: 10px 12px;
    font-size: 14px;
    font-weight: 400;
    color: var(--ndgo-ink);
    text-decoration: none;
    border: none;
    background: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background var(--ndgo-trans);
    font-family: var(--ndgo-ff);
  }

  .ndgo-mobile-nav > a:hover,
  .ndgo-mobile-drop-btn:hover { background: var(--ndgo-bg); }

  .ndgo-mobile-drop-icon {
    width: 18px; height: 18px;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0; opacity: 0.4;
    transition: transform var(--ndgo-trans), opacity var(--ndgo-trans);
  }

  .ndgo-mobile-drop-btn.open .ndgo-mobile-drop-icon {
    transform: rotate(180deg); opacity: 0.7;
  }

  .ndgo-mobile-drop-icon svg { width: 12px; height: 12px; }

  .ndgo-mobile-drop-content {
    overflow: hidden;
    max-height: 0;
    transition: max-height 0.3s ease;
  }

  .ndgo-mobile-drop-content.open { max-height: 600px; }

  .ndgo-mobile-drop-content a {
    display: block;
    padding: 9px 12px 9px 24px;
    font-size: 13.5px;
    font-weight: 400;
    color: var(--ndgo-mid);
    text-decoration: none;
    border-radius: 7px;
    transition: background var(--ndgo-trans), color var(--ndgo-trans);
  }

  .ndgo-mobile-drop-content a:hover { background: var(--ndgo-bg); color: var(--ndgo-ink); }

  .ndgo-mobile-rule { height: 1px; background: var(--ndgo-rule); margin: 8px 4px; }

  .ndgo-mobile-theme-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 12px;
    font-size: 14px;
    color: var(--ndgo-ink);
  }

  .ndgo-mobile-theme-row button {
    background: var(--ndgo-bg);
    border: 1px solid var(--ndgo-rule);
    border-radius: 7px;
    width: 38px; height: 34px;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer;
    font-size: 15px;
    color: var(--ndgo-mid);
    transition: background var(--ndgo-trans);
  }

  .ndgo-mobile-nav .ndgo-cta {
    display: flex !important;
    justify-content: center;
    width: 100%;
    margin-top: 8px;
    padding: 11px 18px !important;
    font-size: 14px !important;
    border-radius: 8px;
  }

  @media (max-width: 1024px) {
    .ndgo-nav             { display: none; }
    .ndgo-header-right .ndgo-cta { display: none; }
    .ndgo-header-right .ndgo-theme-toggle { display: none; }
    .ndgo-ham             { display: flex; margin-left: auto; }
    .ndgo-header-inner    { padding: 0 20px; }
  }
</style>

<header class="ndgo-header" id="ndgo-header">
  <div class="ndgo-header-inner">

    <a href="index.html" class="ndgo-logo">
      <span class="ndgo-logo-mark">NDGO</span>
      <span class="ndgo-logo-dot"></span>
    </a>

    <nav class="ndgo-nav">
      <a href="index.html" class="ndgo-nav-link">Home</a>
      <a href="about.html" class="ndgo-nav-link">About</a>

      <div class="ndgo-nav-item">
        <a href="index.html#services" class="ndgo-nav-link">
          Services
          <svg class="ndgo-nav-chevron" viewBox="0 0 8 8" fill="none" stroke="currentColor" stroke-width="1.8">
            <polyline points="1,3 4,6 7,3"/>
          </svg>
        </a>
        <div class="ndgo-dropdown">
          <div class="ndgo-dd-inner">
            <div class="ndgo-dd-intro">
              <h4>Our Services</h4>
              <p>Flexible support for companies that need smart custom systems — from early discovery through execution.</p>
            </div>
            <div class="ndgo-dd-grid">
              <a href="index.html#services" class="ndgo-dd-item">
                <strong>Solution Discovery</strong>
                <span>Stakeholder interviews, workflow mapping, and roadmapping</span>
              </a>
              <a href="index.html#services" class="ndgo-dd-item">
                <strong>Custom Internal Tools</strong>
                <span>Admin systems, approval flows, and team portals</span>
              </a>
              <a href="index.html#services" class="ndgo-dd-item">
                <strong>Client Portals</strong>
                <span>Onboarding platforms and account dashboards</span>
              </a>
              <a href="index.html#services" class="ndgo-dd-item">
                <strong>Workflow Automation</strong>
                <span>Connect systems, sync data, remove repetitive work</span>
              </a>
              <a href="index.html#services" class="ndgo-dd-item">
                <strong>Dashboard Systems</strong>
                <span>Centralized reporting and performance visibility</span>
              </a>
              <a href="index.html#services" class="ndgo-dd-item">
                <strong>MVP Build</strong>
                <span>Test ideas before larger investment</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      <a href="process.html" class="ndgo-nav-link">Process</a>
      <a href="casestudy.html" class="ndgo-nav-link">Case Studies</a>
    </nav>

    <div class="ndgo-header-right">
      <button class="ndgo-theme-toggle" id="ndgo-theme-toggle" type="button" aria-label="Toggle theme">
        <span class="ndgo-theme-icon">&#9790;</span>
      </button>
      <a href="contact.html" class="ndgo-cta">Get in touch</a>
    </div>

    <button class="ndgo-ham" id="ndgo-ham" aria-label="Toggle menu">
      <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round">
        <line class="ndgo-ham-line ndgo-ham-top"    x1="2" y1="4.5"  x2="14" y2="4.5"/>
        <line class="ndgo-ham-line ndgo-ham-mid"    x1="2" y1="8"    x2="14" y2="8"/>
        <line class="ndgo-ham-line ndgo-ham-bottom" x1="2" y1="11.5" x2="14" y2="11.5"/>
      </svg>
    </button>

  </div>
</header>

<nav class="ndgo-mobile-nav" id="ndgo-mobile-nav">
  <a href="index.html">Home</a>
  <a href="about.html">About</a>
  <div>
    <button class="ndgo-mobile-drop-btn" data-ndgo-drop>
      <span>Services</span>
      <span class="ndgo-mobile-drop-icon">
        <svg viewBox="0 0 8 8" fill="none" stroke="currentColor" stroke-width="1.8">
          <polyline points="1,3 4,6 7,3"/>
        </svg>
      </span>
    </button>
    <div class="ndgo-mobile-drop-content">
      <a href="index.html#services">Solution Discovery</a>
      <a href="index.html#services">Custom Internal Tools</a>
      <a href="index.html#services">Client Portals</a>
      <a href="index.html#services">Workflow Automation</a>
      <a href="index.html#services">Dashboard Systems</a>
      <a href="index.html#services">MVP Build</a>
    </div>
  </div>
  <a href="process.html">Process</a>
  <a href="casestudy.html">Case Studies</a>
  <div class="ndgo-mobile-rule"></div>
  <div class="ndgo-mobile-theme-row">
    <span>Theme</span>
    <button id="ndgo-mobile-theme-toggle" aria-label="Toggle theme">&#9790;</button>
  </div>
  <div class="ndgo-mobile-rule"></div>
  <a href="contact.html" class="ndgo-cta">Get in touch</a>
</nav>
`;


// ─────────────────────────────────────────────────────────────────────────────
// FOOTER
// ─────────────────────────────────────────────────────────────────────────────
const footerHTML = `
<style>
  .ndgo-footer {
    background: var(--ndgo-white);
    border-top: 1px solid var(--ndgo-rule);
    font-family: var(--ndgo-ff);
    color: var(--ndgo-ink);
  }

  .ndgo-footer-main {
    max-width: 1200px;
    margin: 0 auto;
    padding: 64px 40px 48px;
    display: grid;
    grid-template-columns: 1.8fr 1fr 1fr;
    gap: 56px;
  }

  .ndgo-footer-logo {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    margin-bottom: 14px;
  }

  .ndgo-footer-logo-mark {
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 3.5px;
    color: var(--ndgo-ink);
    text-transform: uppercase;
    position: relative;
    padding-bottom: 2px;
  }

  .ndgo-footer-logo-mark::after {
    content: '';
    position: absolute;
    bottom: 0; left: 0;
    width: 100%; height: 2px;
    background: var(--ndgo-accent);
    border-radius: 1px;
  }

  .ndgo-footer-logo-dot {
    width: 4px; height: 4px;
    border-radius: 50%;
    background: var(--ndgo-accent);
    flex-shrink: 0;
    margin-bottom: 1px;
  }

  .ndgo-footer-brand p {
    font-size: 13px;
    font-weight: 300;
    color: var(--ndgo-mid);
    line-height: 1.7;
    max-width: 300px;
    margin: 0 0 20px;
  }

  .ndgo-footer-col h4 {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    color: var(--ndgo-ink);
    margin: 0 0 16px;
  }

  .ndgo-footer-col ul {
    list-style: none;
    padding: 0; margin: 0;
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .ndgo-footer-col a {
    font-size: 13px;
    font-weight: 300;
    color: var(--ndgo-mid);
    text-decoration: none;
    transition: color var(--ndgo-trans);
  }

  .ndgo-footer-col a:hover { color: var(--ndgo-ink); }

  .ndgo-footer-bottom {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px 40px 28px;
    border-top: 1px solid var(--ndgo-rule);
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
  }

  .ndgo-footer-copy {
    font-size: 12px;
    font-weight: 300;
    color: #9ca3af;
  }

  .ndgo-footer-legal { display: flex; gap: 24px; }

  .ndgo-footer-legal a {
    font-size: 12px; font-weight: 300; color: #9ca3af; text-decoration: none;
    transition: color var(--ndgo-trans);
  }
  .ndgo-footer-legal a:hover { color: var(--ndgo-mid); }

  .ndgo-footer-social { display: flex; gap: 6px; }

  .ndgo-footer-social a {
    width: 32px; height: 32px;
    border-radius: 7px;
    border: 1px solid var(--ndgo-rule);
    display: flex; align-items: center; justify-content: center;
    font-size: 12px;
    font-family: var(--ndgo-ff);
    color: var(--ndgo-mid);
    text-decoration: none;
    transition: background var(--ndgo-trans), border-color var(--ndgo-trans), color var(--ndgo-trans);
  }

  .ndgo-footer-social a:hover {
    background: var(--ndgo-bg);
    border-color: #d1d5db;
    color: var(--ndgo-ink);
  }

  [data-theme="dark"] .ndgo-footer-social a:hover {
    background: #2a2d38;
    border-color: #3a3d48;
  }

  @media (max-width: 1024px) {
    .ndgo-footer-main { grid-template-columns: 1fr 1fr; gap: 40px; }
    .ndgo-footer-brand { grid-column: 1 / -1; }
  }

  @media (max-width: 640px) {
    .ndgo-footer-main { grid-template-columns: 1fr; padding: 40px 24px 32px; }
    .ndgo-footer-bottom { flex-direction: column; align-items: flex-start; padding: 18px 24px 28px; }
    .ndgo-footer-legal { flex-wrap: wrap; gap: 14px; }
  }
</style>

<footer class="ndgo-footer">
  <div class="ndgo-footer-main">

    <div class="ndgo-footer-brand">
      <a href="index.html" class="ndgo-footer-logo">
        <span class="ndgo-footer-logo-mark">NDGO</span>
        <span class="ndgo-footer-logo-dot"></span>
      </a>
      <p>Bespoke digital systems, internal tools, and workflow automation — built around how your team actually operates.</p>
    </div>

    <div class="ndgo-footer-col">
      <h4>Services</h4>
      <ul>
        <li><a href="index.html#services">Solution Discovery</a></li>
        <li><a href="index.html#services">Custom Internal Tools</a></li>
        <li><a href="index.html#services">Client Portals</a></li>
        <li><a href="index.html#services">Workflow Automation</a></li>
        <li><a href="index.html#services">Dashboard Systems</a></li>
        <li><a href="index.html#services">MVP Build</a></li>
      </ul>
    </div>

    <div class="ndgo-footer-col">
      <h4>Company</h4>
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="index.html#about">About</a></li>
        <li><a href="process.html">Process</a></li>
        <li><a href="casestudy.html">Case Studies</a></li>
        <li><a href="contact.html">Contact</a></li>
      </ul>
    </div>

  </div>

  <div class="ndgo-footer-bottom">
    <span class="ndgo-footer-copy">&copy; 2026 North Star Design Growth &amp; Operations. All rights reserved.</span>
    <div class="ndgo-footer-legal">
      <a href="#">Privacy</a>
      <a href="#">Terms</a>
    </div>
    <div class="ndgo-footer-social">
      <a href="#" aria-label="LinkedIn">in</a>
      <a href="#" aria-label="X">&#120143;</a>
      <a href="#" aria-label="Email">&#9993;</a>
    </div>
  </div>
</footer>
`;


// ─────────────────────────────────────────────────────────────────────────────
// INJECT + INIT
// ─────────────────────────────────────────────────────────────────────────────
function ndgoInit() {
  const hp = document.getElementById('header-placeholder');
  const fp = document.getElementById('footer-placeholder');
  if (hp) hp.innerHTML = headerHTML;
  if (fp) fp.innerHTML = footerHTML;

  document.body.style.paddingTop = 'var(--ndgo-h, 64px)';

  // ── Scroll effect ──
  const header = document.getElementById('ndgo-header');
  if (header) {
    window.addEventListener('scroll', () => {
      header.classList.toggle('is-scrolled', window.scrollY > 20);
    }, { passive: true });
  }

  // ── Mobile menu ──
  const ham       = document.getElementById('ndgo-ham');
  const mobileNav = document.getElementById('ndgo-mobile-nav');

  function closeMobile() {
    ham?.classList.remove('open');
    mobileNav?.classList.remove('open');
    header?.classList.remove('menu-open');
  }

  if (ham && mobileNav) {
    ham.addEventListener('click', () => {
      ham.classList.toggle('open');
      mobileNav.classList.toggle('open');
      header?.classList.toggle('menu-open');
    });

    document.addEventListener('click', e => {
      if (mobileNav.classList.contains('open') &&
          !mobileNav.contains(e.target) &&
          !ham.contains(e.target)) closeMobile();
    });

    mobileNav.querySelectorAll('a').forEach(a =>
      a.addEventListener('click', closeMobile)
    );
  }

  // ── Mobile dropdown ──
  document.querySelectorAll('[data-ndgo-drop]').forEach(btn => {
    btn.addEventListener('click', () => {
      const content = btn.nextElementSibling;
      document.querySelectorAll('[data-ndgo-drop]').forEach(other => {
        if (other !== btn) {
          other.classList.remove('open');
          other.nextElementSibling?.classList.remove('open');
        }
      });
      btn.classList.toggle('open');
      content?.classList.toggle('open');
    });
  });

  // ── Theme toggle ──
  function getTheme() {
    return document.documentElement.getAttribute('data-theme') || 'light';
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    document.body.classList.toggle('dark-mode', theme === 'dark');
    localStorage.setItem('ndgo-theme', theme);

    const icon = theme === 'dark' ? '☀' : '☾';
    const dt = document.getElementById('ndgo-theme-toggle');
    const mt = document.getElementById('ndgo-mobile-theme-toggle');
    if (dt) {
      const ic = dt.querySelector('.ndgo-theme-icon');
      if (ic) ic.innerHTML = icon;
    }
    if (mt) mt.innerHTML = icon;

    // Sync theme-aware logos
    document.querySelectorAll('.theme-aware-logo').forEach(img => {
      const src = theme === 'dark' ? img.dataset.logoDark : img.dataset.logoLight;
      if (src) img.src = src;
    });

    // Sync original toggle label
    const origLabel = document.querySelector('.theme-toggle-label');
    if (origLabel) origLabel.textContent = theme === 'dark' ? 'Light' : 'Dark';
  }

  function toggleTheme() {
    applyTheme(getTheme() === 'dark' ? 'light' : 'dark');
  }

  document.getElementById('ndgo-theme-toggle')?.addEventListener('click', toggleTheme);
  document.getElementById('ndgo-mobile-theme-toggle')?.addEventListener('click', toggleTheme);

  // Init from localStorage or system preference
  const saved = localStorage.getItem('ndgo-theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  applyTheme(saved || (prefersDark ? 'dark' : 'light'));
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', ndgoInit);
} else {
  ndgoInit();
}